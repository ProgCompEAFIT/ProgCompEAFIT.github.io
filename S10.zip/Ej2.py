import Ej1

print "Se muestra siempre en Ej2"

if __name__ == "__main__":
    print "Se muestra si no es importacion estoy en Ej2"
    print __name__

print(Ej1.readfile())
