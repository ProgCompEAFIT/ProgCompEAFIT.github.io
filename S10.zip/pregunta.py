lista = ["a","b","c","d"]

print lista
del(lista[0])
print lista
lista.remove("c")
print lista
